<!doctype html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>php content</title>
  <link rel="stylesheet" type="text/css" href="./css/style.css">
</head>
  <header>
    <nav>
      <ul>
        <li>
          <a href="./?page=home">главная</a>
        </li>
        <li>
          <a href="./?page=content">статьи</a>
        </li>
        <li>
          <a href="./?page=img">галерея</a>
        </li>
        <li>
          <a href="./?page=contact">контакты</a>
        </li>
        <li>
          <a href="./?page=404">error</a>
        </li>
      </ul>
    </nav>
  </header>
<body>
