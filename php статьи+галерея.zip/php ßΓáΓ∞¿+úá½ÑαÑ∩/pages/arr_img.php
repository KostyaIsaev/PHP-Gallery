<?php
  return [1=>"./image/1.jpg",2=>"./image/2.jpg",3=>"./image/3.jpg",4=>"./image/4.jpg",5=>"./image/5.jpg",6=>"./image/6.jpg",7=>"./image/7.jpg",8=>"./image/8.jpg",9=>"./image/9.jpg",0=>"./image/10.jpg"]
 ?>
